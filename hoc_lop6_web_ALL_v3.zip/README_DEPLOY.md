# 🚀 Đưa website lên mạng (GitHub Pages)
1) Tạo tài khoản GitHub
2) New repository → Public
3) Upload toàn bộ file trong thư mục này
4) Settings → Pages → Source: main / root → Save
5) Mở link được cấp (mất ~1 phút)

✔ Miễn phí • Không cần server
